#include "main.h"
#include <stdlib.h>

/* Update database function definition */
status update_db(c_db *hash_t)
{
    char line[200], newfile[100], c;
    int index;

    /* Reading the backed-up file from user */
    printf("Enter the file to update: \n");
    scanf("%s", newfile);

    /* Opening the backup file in read mode */
    FILE *fptr = fopen(newfile, "r");
    if (fptr == NULL)
    {
        printf("File not found\n");
        return e_failure;
    }

    /* Reading line by line from backup file until fptr reaches EOF */
    while (fgets(line, sizeof(line), fptr) != NULL)
    {
        sscanf(line, "%s", newfile);  // Read the line and process
        
        if (newfile[0] != '#') {
            return e_failure;  // Skip if not a valid line
        }

        /* Extracting index from the line */
        char *token = strtok(newfile + 1, ";");  // Skip the '#'
        if (token == NULL) {
            return e_failure;
        }
        index = atoi(token);  // Convert to integer

        /* Create a new main node and updating the data */
        m_node *m_new = malloc(sizeof(m_node));
        if (m_new == NULL)
        {
            fclose(fptr);
            return e_failure;
        }
        m_new->m_main_link = NULL;
        strcpy(m_new->word, strtok(NULL, ";"));
        m_new->file_count = atoi(strtok(NULL, ";"));

        /* Creating a new subword node and updating the data */
        s_node *s_new = malloc(sizeof(s_node));
        s_node *stemp;
        if (s_new == NULL)
        {
            fclose(fptr);
            return e_failure;
        }
        s_new->s_sub_link = NULL;
        strcpy(s_new->file_name, strtok(NULL, ";"));
        s_new->word_count = atoi(strtok(NULL, ";"));
        m_new->m_sub_link = s_new;
        stemp = s_new;

        /* Loop to create more sub nodes based on file count */
        for (int i = 0; i < (m_new->file_count)-1; i++)
        {
            s_node *s_new = malloc(sizeof(s_node));
            if (s_new == NULL)
            {
                fclose(fptr);
                return e_failure;
            }
            s_new->s_sub_link = NULL;
            strcpy(s_new->file_name, strtok(NULL, ";"));
            s_new->word_count = atoi(strtok(NULL, ";"));
            stemp->s_sub_link = s_new;
            stemp = s_new;
        }

        /* Inserting the new main node into the hashtable */
        if (index < 0 || index >= 27)
        {
            fclose(fptr);
            return e_failure;  // Invalid index
        }

        m_node *temp = hash_t[index].m_link;
        if (temp == NULL)
        {
            hash_t[index].m_link = m_new;
        }
        else
        {
            while (temp->m_main_link)
            {
                temp = temp->m_main_link;
            }
            temp->m_main_link = m_new;
        }
    }
    fclose(fptr);
    return e_success;
}

