#include "main.h"

int main(int argc, char *argv[])
{
    int option;
    char choose;
    f_list *head = NULL;
    c_db arr[27];

    for (int i = 0; i < 27; i++)
    {
        arr[i].key = i;
        arr[i].m_link = NULL;
    }

    if (argc <= 1)
    {
        printf("Error : Insufficient Arguments\nUsage : ./a.out file1.txt file2.txt\n");
        return 0;
    }
    else
    {
        if (read_and_validate(argc, argv, &head) == e_success)
        {
            do
            {
                printf("1. Create DataBase\n2. Display DataBase\n3. Update DataBase\n4. Search DataBase\n5. Save DataBase\n6. Exit\nEnter your choice : ");
                scanf("%d", &option);
                switch (option)
                {
                case 1:
                    if (create_db(head, arr) == e_success)
                        printf("DataBase Created Successfully\n");
                    else
                        printf("Error : Failed To Create Database\n");
                    break;
                case 2:
                    display_db(arr);
                    break;
                case 3:
                    // Remove the check for f == 0, so the database can be updated after creation
                    if (update_db(arr) == e_success)
                        printf("Database Updated Successfully\n");
                    else
                        printf("Error : Failed To Update Database\n");
                    break;
                case 4:
                    if (search_db(arr) == DATA_NOT_FOUND)
                        printf("Word Not Found\n");
                    break;
                case 5:
                    if (save_db(arr) == e_success)
                        printf("Database Saved Successfully\n");
                    else
                        printf("Error : Failed To Save Database\n");
                    break;
                case 6:
                    printf("Exit Successfully\n");
                    return 0;
                    break;
                default:
                    printf("Invalid choice. Please enter a valid option.\n");
                    break;
                }
                printf("Do you want to continue (y/n) : ");
                scanf(" %c", &choose);
            } while (choose == 'y' || choose == 'Y');
        }
        return 0;
    }
}
